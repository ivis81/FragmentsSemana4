package com.iv.tareapetagram.adapter;

import android.app.Activity;
import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.iv.tareapetagram.Mascota;
import com.iv.tareapetagram.R;

import java.util.ArrayList;

/**
 * Created by Ivis on 06/05/2017.
 */

public class PerfilAdaptador extends RecyclerView.Adapter<PerfilAdaptador.PerfilViewHolder> {
    ArrayList<Mascota> mascotas;
    Activity activity;
    private Context mcontext;

    public PerfilAdaptador(ArrayList<Mascota> mascotas){
        this.mascotas = mascotas;
    }

    @Override
    public PerfilViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_view_perfil,parent,false);
        return new PerfilAdaptador.PerfilViewHolder(v);
    }

    @Override
    public void onBindViewHolder(PerfilViewHolder perfilViewHolder, int position) {
        final Mascota mascota = mascotas.get(position);
        perfilViewHolder.imgPerfil.setImageResource(mascota.getFoto());
        //perfilViewHolder.tvNombreMascotaPerfil.setText(mascota.getNombre().toString());
        perfilViewHolder.tvLikePerfil.setText("" + mascota.getLike());

        if(mascota.getSexo()=='f')
            perfilViewHolder.imgPerfil.setBackgroundResource(R.color.colorAccent);
        else
            perfilViewHolder.imgPerfil.setBackgroundResource(R.color.colorPrimary);
    }

    @Override
    public int getItemCount() {
        return mascotas.size();
    }

    public static class PerfilViewHolder extends RecyclerView.ViewHolder {
        private ImageView imgPerfil;
        private TextView tvNombrePerfil, tvLikePerfil;
        public View miView;
        private CardView cvPerfil;
        //private ImageView imgHuesoAmarillo;

        public PerfilViewHolder(View itemView) {
            super(itemView);
            miView = itemView;
            imgPerfil = (ImageView) itemView.findViewById(R.id.imgPerfil);
            tvNombrePerfil = (TextView) itemView.findViewById(R.id.tvNombrePerfil);
            tvLikePerfil = (TextView) itemView.findViewById(R.id.tvLikePerfil);
            //cvPerfil = (CardView) itemView.findViewById(R.id.cvPerfil);
            //imgHuesoAmarillo = (ImageView) itemView.findViewById(R.id.imgHuesoBlanco);

        }

    }


}
