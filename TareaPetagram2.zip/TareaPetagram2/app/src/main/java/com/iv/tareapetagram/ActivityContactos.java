package com.iv.tareapetagram;

import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;


public class ActivityContactos extends AppCompatActivity implements View.OnClickListener{
    private Button btnEnviar;
    private TextInputEditText nombre;
    private TextInputEditText correo;
    private EditText mensaje;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contactos);
        Toolbar miActionBar = (Toolbar) findViewById(R.id.miActionBarFavoritos);
        setSupportActionBar(miActionBar);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        btnEnviar = (Button) findViewById(R.id.btnEnviar);
        nombre = (TextInputEditText) findViewById(R.id.tietNombre);
        correo = (TextInputEditText) findViewById(R.id.tietCorreo);
        mensaje = (EditText) findViewById(R.id.eTextMensaje);

        btnEnviar.setOnClickListener(this);

    }

    private void sendEmail(){
        //Getting content for email
        String email = correo.getText().toString().trim();
        String name = nombre.getText().toString().trim();
        String message = mensaje.getText().toString().trim();

        //Creating SendMail object
        SendMail sm = new SendMail(this, email, name, message);

        //Executing sendmail to send mail
        sm.execute();
    }

    @Override
    public void onClick(View v) {
        sendEmail();
    }
}
