package com.iv.tareapetagram.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.iv.tareapetagram.Mascota;
import com.iv.tareapetagram.R;
import com.iv.tareapetagram.adapter.MascotaAdaptador;

import java.util.ArrayList;

/**
 * Created by Ivis on 03/05/2017.
 */

public class RecyclerViewFragment extends Fragment {


    ArrayList<Mascota> mascotas;
    private RecyclerView rvContactos;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_recyclerview, container,false);

        rvContactos = (RecyclerView) v.findViewById(R.id.rvFragmentMascotas);


        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);

        rvContactos.setLayoutManager(llm);
        inicializarListaMascotas();
        inicializaAdaptador();

        //Toast.makeText(this.getContext(),"RecyclerViewFragment method",Toast.LENGTH_LONG).show();

        return v;
    }

    public void inicializaAdaptador(){
        MascotaAdaptador adaptador = new MascotaAdaptador(mascotas,getActivity());
        rvContactos.setAdapter(adaptador);
    }

    public void inicializarListaMascotas(){
        mascotas = new ArrayList<Mascota>();

        mascotas.add(new Mascota(R.drawable.corgi,"Corgi",2,'m'));
        mascotas.add(new Mascota(R.drawable.corgi2,"Corgi2",1,'f'));
        mascotas.add(new Mascota(R.drawable.dog_48,"Tomy",5,'m'));
        mascotas.add(new Mascota(R.drawable.dog_50,"Catty",5,'f'));
        mascotas.add(new Mascota(R.drawable.german_shepherd,"Sam",6,'f'));
        mascotas.add(new Mascota(R.drawable.hachiko,"Hatchy",7,'m'));

    }
}
